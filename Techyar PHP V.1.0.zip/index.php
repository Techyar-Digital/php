<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/style.css" >
<meta http-equiv="refresh" content="">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.4.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
<link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.4.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<title>Techyar - Secure Mods and Safe Courses</title>
</head>
<body>
    
    <?php
// Function to read JSON file
function readStatusFile($file) {
    $jsonString = file_get_contents($file);
    return json_decode($jsonString, true);
}

// Path to your status JSON file
$statusFile = 'admin/website_status.json';

// Read the status from JSON file
$statusData = readStatusFile($statusFile);

// Check if status is active
if (!($statusData && isset($statusData['status']) && $statusData['status'] === 'active')) {
    // Redirect to maintenance page if status is not active
    header('Location: maintanence.html');
    exit();
}
?>

<nav>
  <div class="logo-bar" >
	<!--<i class="fi fi-rr-bars-sort nav-bar"></i>-->
	<i class="far fa-bars nav-bar" id="open-nav" ></i>
	<img src="img/logo.png" >
  </div>
  
  <div class="nav-expand" id="nav-expand" >
  <div class="close-btn" id="close-nav" >
    <i class="fi fi-rr-angle-double-left" ></i>
  </div>
  
  <div class="options" >
    <img src="img/logo.png" >
  
    <a href="" ><i class="far fa-home" ></i>Home</a>
    <a href="" ><i class="far fa-question-circle" ></i>About</a>
    <a href="" ><i class="far fa-headset" ></i>Contact Us</a>
    
    <strong>Mod Channels</strong>
    
    <a href="" ><i class="fi fi-rr-channel"></i>Get It Free</a>
    <a href="" ><i class="fi fi-rr-channel"></i>Nexus Tech</a>
    <a href="" ><i class="fi fi-rr-channel"></i>Tech Zone</a>
    
    <strong>Courses</strong>
    
    <a href="" ><i class="fi fi-rr-lesson"></i>App Development</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>Web Development</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>Digital Marketing</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>SM Marketing</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>SEO</a>
    
    <strong>Services</strong>
    
    <a href="" ><i class="fi fi-rr-lesson"></i>Free Youtube Views</a>
    <a href="yt_video_analyzer.html" ><i class="fi fi-rr-lesson"></i>Youtube Video Analyzer</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>Digital Marketing</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>SM Marketing</a>
    <a href="" ><i class="fi fi-rr-lesson"></i>SEO</a>
    

    </div>
  </div>
</nav>

<div class="slider-container">
    <div class="slider">
        <img src="img/slider1.jpeg" alt="slider">
        <img src="img/slider2.jpeg" alt="slider">
    </div>
</div>
<div class="dots"></div>

<!-- Search Box -->

<div class="search-box" >
	<input type="search" placeholder="Search mods and course..." >
	<button class="search-btn" ><i class="far fa-search" ></i>Search</button>
</div>

<div class="category-btn-div" >
	<button class="category-btn" ><i class="fab fa-android shade-green" ></i>
	<p>Apk's</p></button>
	<button class="category-btn" ><i class="fa fa-book shade-purple" ></i>
	<p>Courses</p></button>
	<button class="category-btn" ><i class="fa fa-badge-check shade-sky"></i>
	<p>Paid Files</p></button>
</div>

<hr>

<!--Apk's Showing-->
<section class="section" >
<h2>Trending Downloads</h2>

<div class="apk-overflow" >

	<div class="apk-mini-box" >
		<img src="apk/icon/icon1.png" class="apk-icon" alt="icon" >
		<div class="mini-app-name-downloads" >
			<span class="mini-apk-name" >Freefire max by Garena</span>
			<small class="mini-apk-downloads" ><i class="far fa-download" ></i>1B+</small>
		</div>
	</div>
	
</div>
</section>

<hr>

<section class="section" >
<h2>Top Paid Courses</h2>

<div class="apk-overflow" >

	<div class="apk-mini-box" >
		<img src="apk/icon/icon1.png" class="apk-icon" alt="icon" >
		<div class="mini-app-name-downloads" >
			<span class="mini-apk-name" >Freefire max by Garena</span>
			<small class="mini-apk-downloads" ><i class="far fa-hand-holding-dollar" ></i>1B+</small>
		</div>
	</div>
	
</div>
</section>

<hr>

<section class="section" >
<small style="text-align:center;display:block;margin:-10px 0px 10px 0px;" >Advertisement</small>
	<div class="advertisement" style="width:100%;height:200px;background-color:#4e4e4e10;" >
	</div>
</section>

<footer>
  <div class="footer-logo">
    <img src="img/logo.png" alt="Logo">
  </div>
  <div class="footer-sections">
    <strong class="footer-section-titles">Company</strong>
    <a href="">About Us</a>
    <a href="">Contact Us</a>
    <a href="">Articles</a>
  </div>
  <div class="footer-sections">
    <strong class="footer-section-titles">Products</strong>
    <a href="">Online Cources</a>
    <a href="">Secure Mods</a>
    <a href="">Techyar Ideas</a>
    <a href="">Techyar Digital</a>
    <a href="">Techyar Portfolio</a>
  </div>
  <div class="footer-icons-sections">
    <strong class="footer-section-titles">Follow Us On</strong>
    <a href="" class="fab fa-facebook"></a>
    <a href="" class="fab fa-instagram"></a>
    <a href="" class="fab fa-youtube"></a>
    <br>
    <div style="font-size: 11px; width: 100%;
    background-color: #2196f3;color: white;padding: 6px;">
    Proudly Powered By Techyar.
  </div>
  </div>
</footer>
</body>
</html>
