async function analyzeVideo() {
    const videoUrl = document.getElementById('video-url').value;
    const videoId = extractVideoId(videoUrl);
    const detailsContainer = document.getElementById('video-details');

    if (!videoId) {
        const error = document.getElementById('url-error');
        error.style.display = 'block';
        detailsContainer.style.display = 'none';
        return;
    }

    // Show the "analyzing..." text
    detailsContainer.style.display = 'block';
    detailsContainer.innerHTML = '<p>Analyzing...</p>';

    try {
        const response = await fetch('analyze.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ videoId: videoId })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Network response was not ok: ${response.status} - ${errorText}`);
        }

        const data = await response.json();

        if (data.success) {
            displayVideoDetails(data.video);
        } else {
            alert('Error: ' + data.message);
            detailsContainer.style.display = 'none';
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An unexpected error occurred. Check the console for details.');
        detailsContainer.style.display = 'none';
    }
}

function extractVideoId(url) {
    const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|(?:youtu\.be\/)|(?:youtube\.com\/shorts\/))([\w-]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
}

function displayVideoDetails(video) {
    const detailsContainer = document.getElementById('video-details');
    const tagsHTML = video.snippet.tags ? video.snippet.tags.map(tag => `<span class="tag">${tag}</span>`).join('') : 'None';

    detailsContainer.innerHTML = `
        <img class="yt-video-thumbnail" src="${video.snippet.thumbnails.high.url}" alt="${video.snippet.title} Thumbnail">
        <h2 class="yt-video-title">${video.snippet.title}</h2>
        <div class="seperate-box">
            <span>Video Views <i class="far fa-eye"></i></span>
            <p>${video.statistics.viewCount}</p>
        </div>
        <div class="seperate-box">
            <span>Likes <i class="far fa-thumbs-up"></i></span>
            <p>${video.statistics.likeCount}</p>
        </div>
        <div class="seperate-box">
            <span>Comments <i class="far fa-comments"></i></span>
            <p>${video.statistics.commentCount}</p>
        </div>
        <div class="seperate-box">
            <span>Upload Date <i class="far fa-calendar-alt"></i></span>
            <p>${formatDate(video.snippet.publishedAt)}</p>
        </div>
        <div class="seperate-box-left-align">
            <strong>Tags</strong>
            <p class="video-tags"><span class="yt-video-tags">${tagsHTML}</span></p>
        </div>
        <div class="seperate-box-left-align">
            <strong>Video Description</strong>
            <p class="description">${video.snippet.description}</p>
        </div>
    `;
}

function formatDate(dateString) {
    const options = { day: '2-digit', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-GB', options);
}
