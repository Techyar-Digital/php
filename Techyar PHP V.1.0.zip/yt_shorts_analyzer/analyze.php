<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$videoId = $input['videoId'] ?? null;

if (!$videoId) {
    echo json_encode(['success' => false, 'message' => 'Video ID is required']);
    exit;
}

$apiKey = 'AIzaSyCcsjW9YZGFQNW4fWB8_gQXAGvY51UcsF4'; // Replace with your YouTube API key
$apiUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&id={$videoId}&key={$apiKey}";

$startTime = date('H:i:s'); // Capture the start time (only time)

$response = file_get_contents($apiUrl);
if ($response === FALSE) {
    echo json_encode(['success' => false, 'message' => 'Failed to fetch video details']);
    exit;
}

$data = json_decode($response, true);
if (empty($data['items'])) {
    echo json_encode(['success' => false, 'message' => 'Video not found']);
    exit;
}

$video = $data['items'][0];

// Capture the user's IP address
$userIp = $_SERVER['REMOTE_ADDR'];

// Capture the end time after data processing
$endTime = date('H:i:s'); // Capture the end time (only time)

// Format the date as 'dd Month yyyy'
$currentDate = date('d F Y');

// Prepare the log entry
$logEntry = [
    'ip_address' => $userIp,
    'video_url' => "https://www.youtube.com/watch?v={$videoId}",
    'start_time' => $startTime,
    'end_time' => $endTime,
    'date' => $currentDate
];

// Read the existing log data
$logFile = './../admin/analyze_records.json';
if (file_exists($logFile)) {
    $logData = json_decode(file_get_contents($logFile), true);
} else {
    $logData = [];
}

// Append the new log entry
$logData[] = $logEntry;

// Write the updated log data back to the file
file_put_contents($logFile, json_encode($logData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo json_encode(['success' => true, 'video' => $video]);
?>
