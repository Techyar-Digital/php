document.getElementById('close-nav').addEventListener('click', function() {
  document.getElementById('nav-expand').classList.remove('show');
  document.getElementById('nav-expand').classList.add('hide');
});

document.getElementById('open-nav').addEventListener('click', function() {
  document.getElementById('nav-expand').classList.remove('hide');
  document.getElementById('nav-expand').classList.add('show');
});