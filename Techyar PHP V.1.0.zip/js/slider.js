let currentIndex = 0;
const slides = document.querySelectorAll('.slider img');
const totalSlides = slides.length;

function createDots() {
    const dotsContainer = document.querySelector('.dots');
    for (let i = 0; i < totalSlides; i++) {
        const dot = document.createElement('span');
        dot.addEventListener('click', () => {
            currentIndex = i;
            updateSlide();
            updateDots();
        });
        dotsContainer.appendChild(dot);
    }
}

function updateSlide() {
    document.querySelector('.slider').style.transform = `translateX(-${currentIndex * 100}%)`;
    updateDots();
}

function updateDots() {
    const dots = document.querySelectorAll('.dots span');
    dots.forEach(dot => dot.classList.remove('active'));
    dots[currentIndex].classList.add('active');
}

function nextSlide() {
    currentIndex = (currentIndex < totalSlides - 1) ? currentIndex + 1 : 0;
    updateSlide();
}

setInterval(nextSlide, 5000);

document.querySelector('.slider-container').addEventListener('click', function(event) {
    if (event.offsetX < this.clientWidth / 2) {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : totalSlides - 1;
    } else {
        currentIndex = (currentIndex < totalSlides - 1) ? currentIndex + 1 : 0;
    }
    updateSlide();
});

createDots();
updateDots();