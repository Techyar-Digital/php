<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v5.15.4/css/all.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="./../css/style.css" >
<link rel="icon" href="./../img/favico.png" >
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.4.0/uicons-solid-rounded/css/uicons-solid-rounded.css'>
<link rel='stylesheet' href='https://cdn-uicons.flaticon.com/2.4.0/uicons-regular-rounded/css/uicons-regular-rounded.css'>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
<title>YouTube Video Analyzer By TechYar</title>
</head>
<body>
    
<?php
// Function to read JSON file
function readStatusFile($file) {
    $jsonString = file_get_contents($file);
    return json_decode($jsonString, true);
}

// Path to your status JSON file
$statusFile = './../admin/website_status.json';

// Read the status from JSON file
$statusData = readStatusFile($statusFile);

// Check if status is active
if (!($statusData && isset($statusData['status']) && $statusData['status'] === 'active')) {
    // Redirect to maintenance page if status is not active
    header('Location: maintanence.html');
    exit();
}
?>

<nav>
    <div class="logo-bar">
        <!--<i class="fi fi-rr-bars-sort nav-bar"></i>-->
        <i class="far fa-bars nav-bar" id="open-nav"></i>
        <img src="./../img/logo.png">
    </div>
    <div class="nav-expand" id="nav-expand">
        <div class="close-btn" id="close-nav">
            <i class="fi fi-rr-angle-double-left"></i>
        </div>
        <div class="options">
            <img src="./../img/logo.png">
            <a href=""><i class="far fa-home"></i>Home</a>
            <a href=""><i class="far fa-question-circle"></i>About</a>
            <a href=""><i class="far fa-headset"></i>Contact Us</a>
            <strong>Mod Channels</strong>
            <a href=""><i class="fi fi-rr-channel"></i>Get It Free</a>
            <a href=""><i class="fi fi-rr-channel"></i>Nexus Tech</a>
            <a href=""><i class="fi fi-rr-channel"></i>Tech Zone</a>
            <strong>Courses</strong>
            <a href=""><i class="fi fi-rr-lesson"></i>App Development</a>
            <a href=""><i class="fi fi-rr-lesson"></i>Web Development</a>
            <a href=""><i class="fi fi-rr-lesson"></i>Digital Marketing</a>
            <a href=""><i class="fi fi-rr-lesson"></i>SM Marketing</a>
            <a href=""><i class="fi fi-rr-lesson"></i>SEO</a>
        </div>
    </div>
</nav>

<main>

<h1>YouTube Video <span class="coloured" >Analyzer</span></h1>

<div class="yt-analyze-buttons" >
<a href="http://techyar.netfy.app/yt_video_analyzer/" class="yt-analyzer-btn active-analyzer-btn" >Videos</a>
<a href="http://techyar.netfy.app/yt_shorts_analyzer/" class="yt-analyzer-btn" >Shorts</a>
</div>

<div class="yt-video-searchbar">
    <div class="input-and-icon">
        <input type="search" id="video-url" placeholder="Paste here youtube video URL" required oninput="checkUrlType()">
        <i class="fi fi-rr-paste"></i>
    </div>
    <small id="url-error" style="display:none;">Invalid URL, try again with a valid YouTube URL.</small>
    <button type="submit" onclick="analyzeVideo()">Analyze</button>
</div>

<div class="desktop-view">
<div id="video-details">
    <!-- Video details will be displayed here -->
</div>
<section class="service-details-box" >

    <div class="service-details" >
    <h2>How It Works</h2>
    <p>Techyar YouTube Video analyzer extract the video details in which include Video Title, Description, views, comments, likes, and tags.</p>
    <p>All of the following details which are extracted from any video can help all small youTubers that wants to start their channel.</p>
    <p>They can use our services and paste the big youtuber video url and can be used the details from extracted video to their videos.</p>
    </div>
    
    </section>
    
</div>

</main>


<script src="https://apis.google.com/js/api.js"></script>
<script src="js/analyze.js"></script>
<script src="./../js/block.js"></script>
<script src="./../js/expandable-nav.js"></script>
</body>
</html>
